<?php

return [
    'name' => 'User',
    'menu' => [
        'siderbar_position' => 20,
    ],
];
