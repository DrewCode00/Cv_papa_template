<?php

return [
    'name' => 'Settings',
    'menu' => [
        'siderbar_position' => 1, // Need config !=0
    ],
];
