<?php

return [
    'name' => 'Dashboard',
    'menu' => [
        'siderbar_position' => 1, // Need config !=0
    ],
];
