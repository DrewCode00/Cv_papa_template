<?php

return [
    'name' => 'PagesWebsite',
    'menu' => [
        'siderbar_position' => 6, // Need config !=0
        'bottom_skins_position' => 99,
    ],
];
