<?php

return [
    'name' => 'Contacts',
    'menu' => [
        'header_skins_position' => 4,
        'siderbar_position' => 5,
    ],
];
