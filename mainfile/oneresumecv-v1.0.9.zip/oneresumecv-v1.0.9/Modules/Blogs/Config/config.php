<?php

return [
    'name' => 'Blogs',
    'menu' => [
        'siderbar_position' => 4,
        'header_skins_position' => 3,
    ],
];
