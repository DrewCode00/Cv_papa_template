<?php

return [
    'name' => 'ModulesManager',
    'menu' => [
        'siderbar_position' => 99, // Need config !=0
    ],
];
