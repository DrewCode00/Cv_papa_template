<?php

return [
    'name' => 'Location',
    'menu' => [
        'siderbar_position' => 3,
    ],
];
