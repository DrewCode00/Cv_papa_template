<?php

return [
    'name' => 'Jobs',
    'menu' => [
        'siderbar_position' => 3, // Need config !=0
        'header_top_left' => 1,
        'header_skins_position' => 2,
    ],
];
