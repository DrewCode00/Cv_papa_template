(function($) {
	"use strict";
	
	tinymce.init({
	  plugins: 'link',
	  selector: '#company_description'
	});

})(jQuery); // End of use strict