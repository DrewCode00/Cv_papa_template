<li class="nav-item">
    <a class="nav-link" href="{{ route('companies') }}">
        @lang('Companies')
    </a>
</li>
<li class="nav-item">
    <a class="nav-link" href="{{ route('jobslist') }}">
        @lang('Jobs')
    </a>
</li>