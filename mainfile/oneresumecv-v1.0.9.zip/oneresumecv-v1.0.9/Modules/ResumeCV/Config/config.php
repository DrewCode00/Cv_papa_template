<?php

return [
    'name' => 'ResumeCV',
    'menu' => [
        'siderbar_position' => 2, // Need config !=0
        'header_skins_position' => 3,
    ],
];
