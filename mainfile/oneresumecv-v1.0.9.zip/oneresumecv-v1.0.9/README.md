#Set: fon-family default

Need a div #resumecv-layout for all resume
#resumecv-layout {
    font-family: 'Trebuchet MS';
}