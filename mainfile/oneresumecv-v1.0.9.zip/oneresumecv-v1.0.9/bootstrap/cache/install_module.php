<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Install\\Providers\\InstallServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Install\\Providers\\InstallServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);