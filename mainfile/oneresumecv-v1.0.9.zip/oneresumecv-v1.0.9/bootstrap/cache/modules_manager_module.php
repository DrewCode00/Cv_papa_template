<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ModulesManager\\Providers\\ModulesManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ModulesManager\\Providers\\ModulesManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);