<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Tracklink\\Providers\\TracklinkServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Tracklink\\Providers\\TracklinkServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);